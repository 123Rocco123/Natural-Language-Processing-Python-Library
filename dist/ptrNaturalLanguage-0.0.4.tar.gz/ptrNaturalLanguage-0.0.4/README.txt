The goal of the library is that of allowing developers to quickly and easily analyze finance text files and strings. 

The functions in the package make use of ptrFinance to make and save the requests.
